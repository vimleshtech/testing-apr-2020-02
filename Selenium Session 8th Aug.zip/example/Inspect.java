package example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Inspect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver d = new ChromeDriver();
		d.get("https://www.google.com/");
		
		d.findElement(By.name("q")).sendKeys("selenium");
		d.findElement(By.name("q")).submit();
		
		
		//get url 
		String url  = d.getCurrentUrl();
		System.out.println(url);
		
		//get title 
		String title = d.getTitle();
		System.out.println(title);
		
		//maximize the screen
		d.manage().window().maximize();
		
		//go backward
		d.navigate().back();
		
		//go forward
		d.navigate().forward();
		
		//refresh or reload
		d.navigate().refresh();
		
		//close browser
		d.close();
		
		
	}

}
