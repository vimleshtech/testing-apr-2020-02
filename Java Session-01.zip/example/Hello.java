package example;

public class Hello {

	public static void main(String[] b) {
		
		System.out.println("Hi, this is my first code in java");	
	}
}
