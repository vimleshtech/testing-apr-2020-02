package example;

public class Clac {

	public static void main(String[] args) {
		
		
		int a,b,c;
		
		a =23;
		b =89;
		
		//addition 
		c =a+b;
		
		System.out.println("sum of two numbers "+c);
		
		//substruction 
		c =a-b;
		System.out.println("sub of two numbers "+c);
		
		

		String name ="Rahul Sharma";
		System.out.println("name is "+name);
		
	}

}
