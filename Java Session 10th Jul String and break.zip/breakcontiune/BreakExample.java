package breakcontiune;

import java.util.Scanner;

public class BreakExample {

	public static void main(String[] args) {
		
		
		int day;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter day numnber ");
		day = sc.nextInt();
		
		switch (day) {
			case 1:
				System.out.println("monday");
				break; //stop the switch/ terminate the switch 
			case 2:
				System.out.println("tuesday");
				break; 
			case 3:
				System.out.println("wednesday");
				break; 
			case 4:
				System.out.println("thurday");
				break; 
			case 5:
				System.out.println("friday");
				break; 
			case 6:
				System.out.println("saturday");
				break; 	
			default:
				System.out.println("other day/ weekend");
				break;
			
		}
		
		

	}

}
