package breakcontiune;

public class Continue {

	public static void main(String[] args) {
		
		//break : stop or terminate the loop 
		for(int i=1;i<10;i++) {

			if(i%4==0)  //if i is divisiable by 4
				break; //terminate the loop 
			
			System.out.println(i);
				
		}
		
		//continue : skip the current iteration
		for(int i=1; i<10;i++) {
			
			if(i%3==0)
				continue;
			System.out.println(i);
		}
		
		//1 2 4 5 7 8 
	}

}
