package stringexample;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		String str;
		
		System.out.println("enter string value :");
		str = sc.nextLine(); //nextLine() is function which read string data 
		
		//print
		System.out.println("Output is :"+str);
		
		//convert to upper case 
		String up = str.toUpperCase();		
		System.out.println(up);
		
		//convert to lower case
		String lc = str.toLowerCase();
		System.out.println(lc);
		
		//length
		int l = str.length();
		System.out.println("length is "+l);
		
		//replacement
		String rs = str.replace("a", "xy");//a is old(existing) char and xy is new chars
		System.out.println(rs);
		
		//trim
		String t = str.trim();
		System.out.println(t);
		
		//indexOf()
		int pos = str.indexOf("v");
		System.out.println(pos);
		
		//charAt()
		char c = str.charAt(1);
		System.out.println(c);
		
		//substring 
		String st = str.substring(3,9); //from 3 to <9
		System.out.println(st);
		
		//split
		String names[]= str.split(" "); //break string by space 
		System.out.println(names[0]); //print first name
		System.out.println(names[1]); //print 2nd name
		
		//iterate 
		for(String n: names) {
			System.out.println(n);
		}
		
		
		//
		if(str.equals("raman sinha")) {
			System.out.println("name is match ");
			
		}else {
			System.out.println("name is not match");
		}
		
		//
		if(str.equalsIgnoreCase("raman sinha")) {
			System.out.println("name is match");
		}else {
			System.out.println("name is not match");
		}
		
		//
		if(str.contains("is")) {
			System.out.println("is match ");
		}else {
			System.out.println("is not match");
		}
		
		//
		if(str.startsWith("java")) {
			System.out.println("start with java ");
		}else {
			System.out.println("NOT MATCH ");
		}
		
		//
		if(str.endsWith("language")) {
			System.out.println("language is match");
		}else {
			System.out.println("langauge is not match");
		}

	}

}
