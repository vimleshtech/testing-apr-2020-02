package stringexample;

//Question : C1  to C5
import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {
		
		// Take string input
		String str;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data ");
		str= sc.nextLine();
		
		//Convert to upper case 
		System.out.println(str.toUpperCase());
		
		//Convert to lower case
		System.out.println(str.toLowerCase());
		
		//get length
		System.out.println(str.length());
		
		//remove before and afte space
		System.out.println(str.trim());
		
		//replace 
		System.out.println(str.replace("a", "xy"));
		
		//substring 
		System.out.println(str.substring(2,6)); //cut string from 2 to 5 <6
		
		
		//get position 
		int p = str.indexOf("m");
		System.out.println(p);
		
		
		//get char of given index
		char c = str.charAt(2); //return 3rd char
		System.out.println(c);
		
		
		//condition 
		if(str.equals("raman sinha")) {
			System.out.println("name is match");
		}else {
			System.out.println("name is not match");
		}
		
		//ignore equals
		if(str.equalsIgnoreCase("RAMAN Sinha")) {
				System.out.println("name is match case insensetive");
		}else {
			System.out.println("name is not match");
		}
		
		//match last char/word
		if(str.endsWith("nha")) {
			System.out.println("ending with nha");
		}else {
			System.out.println("not ending with nha");
		}
		
		//match firt char/word
		if(str.startsWith("ram")) {
			System.out.println("firt 3 chars match");
		}else {
			System.out.println("first 3 char not match");
		}
		
		//match anywhere
		if(str.contains("ma")) {
			System.out.println("ma is match");
		}else {
			System.out.println("ma is not match");
		}
	}

}
