package loopexample;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//do while: first execute then check the condition 
		//loop will execute at least one time
		
		int i=1;
		do {
			
			System.out.println(i);
			i++;
		}while(i<1);
	}

}
