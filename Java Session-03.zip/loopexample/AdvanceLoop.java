package loopexample;

public class AdvanceLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//adavance loop work for/with array and collection 
		
		int n[] = {111,4,6,7,3,3};
		
		for(int d: n) { //read data from n to d one by one , here d is new variable and n is array 
			System.out.println(d);
		}
	}

}
