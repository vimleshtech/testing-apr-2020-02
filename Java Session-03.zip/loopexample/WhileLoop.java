package loopexample;

import java.util.Scanner;

public class WhileLoop {

	public static void main(String[] args) {

		//init
		int i=1;
		
		//condition 
		while(i<10) {
			System.out.println(i);
			i++; //increment 
		}
		//print in reverse 
		i=10;
		while(i>0) {
			System.out.println(i);
			i--; //decrement 
		}
		
		//wap to get sum or all numbers between two given input
		int a,b,total=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter first and last number ");
		a = sc.nextInt();
		b =sc.nextInt();
		
		while(a<=b) {
			total+=a;
			a++;
		}

		
		System.out.println("total is "+total);
		
		//wap to print table of given number
		System.out.println("enter number ");
		int n = sc.nextInt();
		
		i=1;
		while(i<=10) {
			System.out.println(i*n);
			i++;
		}
		
	}

}
